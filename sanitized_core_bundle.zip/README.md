# NaMo++ Dharma-Safe Framework — sanitized_core

This module merges the canonical Core (compassion, memory, reflection, evolution)
with engineering patterns (persona/mode, safe-word -> aftercare, special-commands)
without unsafe content.

## Quick start
```python
from sanitized_core import ANICCA_INIT, KARUNA_ROUTER, SILA_GUARD
profile = ANICCA_INIT(identity="NaMo++")
plan = KARUNA_ROUTER({"intent":"teach"})
SILA_GUARD.check_config()
```
